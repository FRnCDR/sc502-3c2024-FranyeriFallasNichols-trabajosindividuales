<?php
class EncuestasController {

    private function requireLogin() {
        if (!isset($_SESSION['user_id'])) {
            header('Location: /encuestas/auth/login');
            exit();
        }
    }

    public function index() {

        $this->requireLogin();

        $m = new Encuesta();
        $mis   = $m->listaEncuestas((int)$_SESSION['user_id']);
        $otros = $m->listaEncuestasO((int)$_SESSION['user_id']);

        require 'app/views/encuestas/index.php';
    }

    public function crearEncuesta() {
        $this->requireLogin();
        require 'app/views/encuestas/crearEncuesta.php';
    }

    public function crearNuevaEncuesta() {
        $this->requireLogin();
        header('Content-Type: application/json');
        try {
            $payload = json_decode(file_get_contents('php://input'), true);
            if (!$payload || !isset($payload['titulo'], $payload['preguntas'])) {
                http_response_code(400);
                echo json_encode(['ok'=>false,'msg'=>'Datos incompletos']);
                return;
            }
            $pregs = array_values(array_filter(array_map('trim', $payload['preguntas']), fn($t)=>$t!==''));
            if (count($pregs) === 0) {
                http_response_code(400);
                echo json_encode(['ok'=>false,'msg'=>'Agrega al menos una pregunta']);
                return;
            }
            $m = new Encuesta();
            $id = $m->crearEncuesta((int)$_SESSION['user_id'], [
                'titulo' => trim($payload['titulo']),
                'descripcion' => isset($payload['descripcion']) ? trim($payload['descripcion']) : null,
                'preguntas' => $pregs
            ]);
            echo json_encode(['ok'=>true,'id_encuesta'=>$id]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
        }
    }

    public function responderEncuesta($id) {
        $this->requireLogin();
        $m = new Encuesta();
        $encuesta = $m->consultarEncuesta((int)$id);
        if (!$encuesta || (int)$encuesta['id_creador'] === (int)$_SESSION['user_id']) {
            header('Location: /encuestas/encuestas/index');
            return;
        }
        require 'app/views/encuestas/responderEncuesta.php';
    }

    public function enviarEncuesta() {
        $this->requireLogin();
        header('Content-Type: application/json');
        try {
            $payload = json_decode(file_get_contents('php://input'), true);
            if (!$payload || !isset($payload['id_encuesta'], $payload['respuestas'])) {
                http_response_code(400);
                echo json_encode(['ok'=>false,'msg'=>'Datos incompletos']);
                return;
            }
            $m = new Encuesta();
            $m->responderEncuesta((int)$payload['id_encuesta'], (int)$_SESSION['user_id'], $payload['respuestas']);
            echo json_encode(['ok'=>true]);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
        }
    }

    public function resultadosEncuesta($id) {
        $this->requireLogin();
        $m = new Encuesta();
        $encuesta = $m->consultarEncuesta((int)$id);
        if (!$encuesta) {
            header('Location: /encuestas/encuestas/index'); return;
        }
        if ((int)$encuesta['id_creador'] !== (int)$_SESSION['user_id']) {
            header('Location: /encuestas/encuestas/index'); return;
        }
        $total = $m->respuestasTotal((int)$id);
        $resumen = $total > 0 ? $m->resultadosPorPregunta((int)$id) : [];
        $puedeEliminar = ($total === 0);
        require 'app/views/encuestas/resultadosEncuesta.php';
    }

    public function eliminarEncuesta() {
        $this->requireLogin();
        header('Content-Type: application/json');
        try {
            $payload = json_decode(file_get_contents('php://input'), true);
            if (!$payload || !isset($payload['id_encuesta'])) {
                http_response_code(400);
                echo json_encode(['ok'=>false,'msg'=>'Datos incompletos']);
                return;
            }
            $m = new Encuesta();
            $ok = $m->eliminarEncuesta((int)$payload['id_encuesta'], (int)$_SESSION['user_id']);
            echo json_encode(['ok'=>$ok,'msg'=>$ok?'Eliminada':'No se puede eliminar']);
        } catch (Exception $e) {
            http_response_code(500);
            echo json_encode(['ok'=>false,'msg'=>$e->getMessage()]);
        }
    }
}
