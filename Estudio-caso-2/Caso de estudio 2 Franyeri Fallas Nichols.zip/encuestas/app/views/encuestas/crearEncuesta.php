<?php include 'app/views/layouts/header.php'; ?>
<main class="container py-4">
  <h3>Registrar encuesta</h3>
  <form id="form-encuesta" class="mt-3">
    <div class="mb-3">
      <label class="form-label">Título</label>
      <input type="text" class="form-control" id="titulo" required />
    </div>

    <div class="mb-3">
      <label class="form-label">Resumen</label>
      <textarea class="form-control" id="descripcion" rows="2" placeholder="Describa brevemente..."></textarea>
    </div>

    <div class="mb-2 d-flex align-items-center justify-content-between">
      <h6 class="m-0">Preguntas para la Encueta</h6>
      <button type="button" class="btn btn-sm btn-outline-secondary" id="btn-add-pregunta">
        <i class="fa fa-plus"></i> Añadir pregunta
      </button>
    </div>

    <div id="zona-preguntas" class="vstack gap-3"></div>

    <div class="mt-3">
      <button type="submit" class="btn btn-primary">
        <i class="fa fa-save"></i> Guardar
      </button>
    </div>
  </form>
</main>
<?php include 'app/views/layouts/footer.php'; ?>

