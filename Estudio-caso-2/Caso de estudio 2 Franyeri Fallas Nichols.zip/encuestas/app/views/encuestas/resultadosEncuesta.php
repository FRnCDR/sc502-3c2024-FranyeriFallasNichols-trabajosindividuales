<?php include 'app/views/layouts/header.php'; ?>
<main class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-2">
    <h3>Resultados: <?php echo htmlspecialchars($encuesta['titulo']); ?></h3>
    <a href="/encuestas/encuestas/index" class="btn btn-outline-secondary">Regresar</a>
  </div>

  <?php if (!empty($encuesta['descripcion'])): ?>
    <p class="text-muted"><?php echo nl2br(htmlspecialchars($encuesta['descripcion'])); ?></p>
  <?php endif; ?>

  <div class="mb-3">
    <span class="badge bg-info">Numero de participantes<?php echo (int)$total; ?></span>
  </div>

  <?php if ($puedeEliminar): ?>
    <button id="btn-eliminar" class="btn btn-danger mb-4" data-id="<?php echo (int)$encuesta['id']; ?>">
      <i class="fa fa-trash"></i> Eliminar
    </button>
  <?php endif; ?>

  <?php if ($total === 0): ?>
    <p class="text-muted">No hay respuestas</p>
  <?php else: ?>
    <?php foreach ($resumen as $pid => $bloque): ?>
      <div class="card mb-3">
        <div class="card-header">
          <?php echo htmlspecialchars($bloque['pregunta']); ?>
        </div>
        <div class="card-body">
          <div class="table-responsive">
            <table class="table table-sm align-middle">
              <thead><tr><th>Valor</th><th>Cantidad</th></tr></thead>
              <tbody>
                <?php for ($v=1;$v<=5;$v++): ?>
                <tr>
                  <td><?php echo $v; ?></td>
                  <td><span class="badge bg-primary rounded-pill"><?php echo (int)$bloque['conteos'][$v]; ?></span></td>
                </tr>
                <?php endfor; ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  <?php endif; ?>
</main>
<?php include 'app/views/layouts/footer.php'; ?>
