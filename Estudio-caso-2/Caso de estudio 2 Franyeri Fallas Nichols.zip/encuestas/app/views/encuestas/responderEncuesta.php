<?php include 'app/views/layouts/header.php'; ?>
<main class="container py-4">
  <h3>Contestar encuesta: <?php echo htmlspecialchars($encuesta['titulo']); ?></h3>
  <?php if (!empty($encuesta['descripcion'])): ?>
    <p class="text-muted"><?php echo nl2br(htmlspecialchars($encuesta['descripcion'])); ?></p>
  <?php endif; ?>

  <form id="form-respuesta" class="mt-3">
    <input type="hidden" id="id_encuesta" value="<?php echo (int)$encuesta['id']; ?>" />
    <?php foreach ($encuesta['preguntas'] as $i => $p): ?>
      <div class="card mb-3">
        <div class="card-header">
          Interrogante <?php echo $i+1; ?>: <?php echo htmlspecialchars($p['texto_pregunta']); ?>
        </div>
        <div class="card-body">
          <div class="row row-cols-5 g-3">
            <?php for ($v=1; $v<=5; $v++): ?>
            <div class="col">
              <div class="form-check text-center">
                <input class="form-check-input" type="radio"
                       name="p_<?php echo (int)$p['id']; ?>"
                       value="<?php echo $v; ?>" required>
                <label class="form-check-label d-block"><?php echo $v; ?></label>
              </div>
            </div>
            <?php endfor; ?>
          </div>
          <small class="text-muted d-block mt-2">Seleccione un numero entre 1 y 5</small>
        </div>
      </div>
    <?php endforeach; ?>

    <button class="btn btn-primary" type="submit">
      <i class="fa fa-paper-plane"></i> Enviar
    </button>
  </form>
</main>
<?php include 'app/views/layouts/footer.php'; ?>
