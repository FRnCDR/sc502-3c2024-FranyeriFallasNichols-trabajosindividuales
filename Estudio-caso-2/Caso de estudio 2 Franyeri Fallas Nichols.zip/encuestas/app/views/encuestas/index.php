<?php include 'app/views/layouts/header.php'; ?>
<main class="container py-4">
  <div class="d-flex justify-content-between align-items-center mb-3">
    <h3>Encuestas</h3>
    <a href="/encuestas/encuestas/crearEncuesta" class="btn btn-primary">
      <i class="fa fa-plus"></i> Crear encuesta nueva
    </a>
  </div>

  <div class="row g-4">
    <div class="col-md-6">
      <div class="card h-100">
        <div class="card-header">Encuestas</div>
        <div class="card-body">
          <?php if (empty($mis)): ?>
            <p class="text-muted">No se han creado encuestas</p>
          <?php else: ?>
            <ul class="list-group">
              <?php foreach ($mis as $e): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center">
                <span><?php echo htmlspecialchars($e['titulo']); ?></span>
                <a class="btn btn-sm btn-outline-secondary" href="/encuestas/encuestas/resultadosEncuesta/<?php echo (int)$e['id']; ?>">
                  <i class="fa fa-chart-bar"></i> Resultados
                </a>
              </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      </div>
    </div>

    <div class="col-md-6">
      <div class="card h-100">
        <div class="card-header">Encuestas creadas</div>
        <div class="card-body">
          <?php if (empty($otros)): ?>
            <p class="text-muted">No hay encuestas</p>
          <?php else: ?>
            <ul class="list-group">
              <?php foreach ($otros as $e): ?>
              <li class="list-group-item d-flex justify-content-between align-items-center">
                <div>
                  <strong><?php echo htmlspecialchars($e['titulo']); ?></strong>
                  <small class="text-muted d-block">Se creó por <?php echo htmlspecialchars($e['autor']); ?></small>
                </div>
                <a class="btn btn-sm btn-outline-primary" href="/encuestas/encuestas/responderEncuesta/<?php echo (int)$e['id']; ?>">
                  <i class="fa fa-edit"></i> Participar
                </a>
              </li>
              <?php endforeach; ?>
            </ul>
          <?php endif; ?>
        </div>
      </div>
    </div>
  </div>
</main>
<?php include 'app/views/layouts/footer.php'; ?>
