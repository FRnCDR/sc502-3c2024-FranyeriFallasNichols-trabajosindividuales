</main>
    <footer class="bg-dark text-white text-center py-3 mt-auto">
        <div class="container">
            <p>EncuestaApp &copy; <?php echo date('Y'); ?></p>
        </div>
    </footer>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>