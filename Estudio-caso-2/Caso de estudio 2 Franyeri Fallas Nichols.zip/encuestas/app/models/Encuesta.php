<?php
class Encuesta {
    private $pdo;

    public function __construct() {
        $this->pdo = getPDOConnection();
    }
   
    public function crearEncuesta(int $idUsuario, array $data): int {
        $this->pdo->beginTransaction();
        try {
            $stmt = $this->pdo->prepare(
                "INSERT INTO encuestas (id_creador, titulo, descripcion, created_at) VALUES (?, ?, ?, NOW())"
            );
            $stmt->execute([$idUsuario, $data['titulo'], $data['descripcion'] ?? null]);
            $idEncuesta = (int)$this->pdo->lastInsertId();

            $stmtP = $this->pdo->prepare("INSERT INTO preguntas (id_encuesta, texto_pregunta) VALUES (?, ?)");
            foreach ($data['preguntas'] as $txt) {
                $txt = trim((string)$txt);
                if ($txt === '') continue;
                $stmtP->execute([$idEncuesta, $txt]);
            }

            $this->pdo->commit();
            return $idEncuesta;
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function consultarEncuesta(int $idEncuesta): ?array {
        $stmt = $this->pdo->prepare(
            "SELECT e.id, e.id_creador, e.titulo, e.descripcion, e.created_at,
                    u.nombre AS autor
             FROM encuestas e
             JOIN usuarios u ON u.id = e.id_creador
             WHERE e.id = ?"
        );
        $stmt->execute([$idEncuesta]);
        $enc = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$enc) return null;

        $stp = $this->pdo->prepare(
            "SELECT id, texto_pregunta FROM preguntas WHERE id_encuesta = ? ORDER BY id"
        );
        $stp->execute([$idEncuesta]);
        $enc['preguntas'] = $stp->fetchAll(PDO::FETCH_ASSOC);

        return $enc;
    }

    public function listaEncuestas(int $idUsuario): array {
        $stmt = $this->pdo->prepare(
            "SELECT id, titulo, created_at FROM encuestas
             WHERE id_creador = ?
             ORDER BY id DESC"
        );
        $stmt->execute([$idUsuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function listaEncuestasO(int $idUsuario): array {
        $stmt = $this->pdo->prepare(
            "SELECT e.id, e.titulo, e.created_at, u.nombre AS autor
             FROM encuestas e
             JOIN usuarios u ON u.id = e.id_creador
             WHERE e.id_creador <> ?
             ORDER BY e.id DESC"
        );
        $stmt->execute([$idUsuario]);
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function responderEncuesta(int $idEncuesta, int $idUsuario, array $respuestas): void {
        $this->pdo->beginTransaction();
        try {
            
            $sp = $this->pdo->prepare(
                "INSERT IGNORE INTO participantes (id_encuesta, id_usuario, created_at)
                 VALUES (?, ?, NOW())"
            );
            $sp->execute([$idEncuesta, $idUsuario]);

            $ids = array_map(fn($r) => (int)$r['id_pregunta'], $respuestas);
            if (!$ids) throw new Exception("No hay respuestas");
            $in = implode(',', array_fill(0, count($ids), '?'));
            $chk = $this->pdo->prepare("SELECT id FROM preguntas WHERE id_encuesta = ? AND id IN ($in)");
            $chk->execute(array_merge([$idEncuesta], $ids));
            $valid = $chk->fetchAll(PDO::FETCH_COLUMN);
            if (count($valid) !== count(array_unique($ids))) {
                throw new Exception("Preguntas inválidas para esta encuesta");
            }

            $sr = $this->pdo->prepare(
                "INSERT INTO respuestas (id_pregunta, id_usuario, valor_respuesta, created_at)
                 VALUES (?, ?, ?, NOW())
                 ON DUPLICATE KEY UPDATE valor_respuesta = VALUES(valor_respuesta), created_at = NOW()"
            );
            foreach ($respuestas as $r) {
                $pid = (int)$r['id_pregunta'];
                $val = (int)$r['valor'];
                if ($val < 1 || $val > 5) continue;
                $sr->execute([$pid, $idUsuario, $val]);
            }

            $this->pdo->commit();
        } catch (Exception $e) {
            $this->pdo->rollBack();
            throw $e;
        }
    }

    public function respuestasTotal(int $idEncuesta): int {
        $stmt = $this->pdo->prepare(
            "SELECT COUNT(DISTINCT r.id_usuario)
             FROM preguntas p
             JOIN respuestas r ON r.id_pregunta = p.id
             WHERE p.id_encuesta = ?"
        );
        $stmt->execute([$idEncuesta]);
        return (int)$stmt->fetchColumn();
    }

    public function resultadosPorPregunta(int $idEncuesta): array {
        $stmt = $this->pdo->prepare(
            "SELECT p.id AS id_pregunta, p.texto_pregunta,
                    r.valor_respuesta, COUNT(r.id) AS total
             FROM preguntas p
             LEFT JOIN respuestas r ON r.id_pregunta = p.id
             WHERE p.id_encuesta = ?
             GROUP BY p.id, p.texto_pregunta, r.valor_respuesta
             ORDER BY p.id"
        );
        $stmt->execute([$idEncuesta]);

        $out = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $pid = (int)$row['id_pregunta'];
            if (!isset($out[$pid])) {
                $out[$pid] = [
                    'pregunta' => $row['texto_pregunta'],
                    'conteos'  => [1=>0,2=>0,3=>0,4=>0,5=>0]
                ];
            }
            $vr = $row['valor_respuesta'];
            if ($vr !== null) {
                $v = (int)$vr;
                if ($v >= 1 && $v <= 5) {
                    $out[$pid]['conteos'][$v] = (int)$row['total'];
                }
            }
        }
        return $out;
    }

    //eliminar la encuesta
    public function puedeEliminar(int $idEncuesta): bool {
        return $this->respuestasTotal($idEncuesta) === 0;
    }

    public function eliminarEncuesta(int $idEncuesta, int $idUsuario): bool {
        if (!$this->puedeEliminar($idEncuesta)) return false;
        $stmt = $this->pdo->prepare("DELETE FROM encuestas WHERE id = ? AND id_creador = ?");
        return $stmt->execute([$idEncuesta, $idUsuario]);
    }
}
