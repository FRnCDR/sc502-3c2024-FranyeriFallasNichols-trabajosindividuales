function nuevaPregunta(index) {
  const wrapper = document.createElement('div');
  wrapper.className = 'card';
  wrapper.innerHTML = `
    <div class="card-header d-flex justify-content-between align-items-center">
      <span>Pregunta #${index + 1}</span>
      <button type="button" class="btn btn-sm btn-outline-danger btn-del-pregunta">
        <i class="fa fa-times"></i>
      </button>
    </div>
    <div class="card-body">
      <div class="mb-2">
        <label class="form-label">Texto de la pregunta</label>
        <input type="text" class="form-control inp-pregunta" placeholder="¿Cuál es tu opinión sobre ...?" required>
      </div>
    </div>
  `;
  return wrapper;
}

document.addEventListener('DOMContentLoaded', () => {
  // vista de crear
  const zonaPreg = document.getElementById('zona-preguntas');
  const btnAddPreg = document.getElementById('btn-add-pregunta');
  const formEncuesta = document.getElementById('form-encuesta');

  if (btnAddPreg && zonaPreg && formEncuesta) {
    const addPregunta = () => {
      const idx = zonaPreg.querySelectorAll('.card').length;
      const card = nuevaPregunta(idx);
      zonaPreg.appendChild(card);
    };

    btnAddPreg.addEventListener('click', addPregunta);
    addPregunta();

    zonaPreg.addEventListener('click', (e) => {
      if (e.target.closest('.btn-del-pregunta')) {
        const card = e.target.closest('.card');
        zonaPreg.removeChild(card);
      }
    });

    formEncuesta.addEventListener('submit', async (e) => {
      e.preventDefault();
      const titulo = document.getElementById('titulo').value.trim();
      const descripcion = (document.getElementById('descripcion')?.value || '').trim();
      if (!titulo) return alert('Ingrese un título');

      const preguntas = [];
      zonaPreg.querySelectorAll('.card').forEach(card => {
        const inp = card.querySelector('.inp-pregunta, .inp-texto');
        const texto = (inp?.value || '').trim();
        if (texto) preguntas.push(texto);
      });

      if (preguntas.length === 0) return alert('Agregue al menos una pregunta.');

      try {
        const res = await fetch('/encuestas/encuestas/crearNuevaEncuesta', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ titulo, descripcion, preguntas })
        });
        const data = await res.json();
        if (data.ok) {
          window.location.href = '/encuestas/encuestas/index';
        } else {
          alert(data.msg || 'Error al guardar');
        }
      } catch (err) {
        console.error(err);
        alert('No se pudo conectar con el servidor.');
      }
    });
  }

  // vista para responder
  const formResp = document.getElementById('form-respuesta');
  if (formResp) {
    formResp.addEventListener('submit', async (e) => {
      e.preventDefault();
      const id_encuesta = parseInt(document.getElementById('id_encuesta').value, 10);
      const respuestas = [];

      formResp.querySelectorAll('.card').forEach(card => {
        const anyRadio = card.querySelector('input[type=radio]');
        if (!anyRadio) return;
        const name = anyRadio.getAttribute('name'); 
        const sel = card.querySelector('input[type=radio]:checked');
        if (!name || !sel) return;

        const id_pregunta = parseInt(name.split('_')[1], 10);
        const valor = parseInt(sel.value, 10); 

        if (Number.isInteger(id_pregunta) && Number.isInteger(valor)) {
          respuestas.push({ id_pregunta, valor });
        }
      });

      if (respuestas.length === 0) return alert('Complete todas las respuestas.');

      try {
        const res = await fetch('/encuestas/encuestas/enviarEncuesta', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id_encuesta, respuestas })
        });
        const data = await res.json();
        if (data.ok) {
          window.location.href = '/encuestas/encuestas/index';
        } else {
          alert(data.msg || 'Error al enviar');
        }
      } catch (err) {
        console.error(err);
        alert('No se pudo conectar con el servidor.');
      }
    });
  }

  // vista de resultados
  const btnEliminar = document.getElementById('btn-eliminar');
  if (btnEliminar) {
    btnEliminar.addEventListener('click', async () => {
      if (!confirm('¿Eliminar la encuesta? Esta acción no se puede deshacer.')) return;
      const id_encuesta = parseInt(btnEliminar.dataset.id, 10);
      try {
        const res = await fetch('/encuestas/encuestas/eliminarEncuesta', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ id_encuesta })
        });
        const data = await res.json();
        if (data.ok) {
          window.location.href = '/encuestas/encuestas/index';
        } else {
          alert(data.msg || 'No se pudo eliminar.');
        }
      } catch (err) {
        console.error(err);
        alert('No se pudo conectar con el servidor.');
      }
    });
  }
});
